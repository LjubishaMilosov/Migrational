package org.migrational;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import java.time.Duration;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class NostrificationTest {

    @Test
    public void nostrificationTest() throws InterruptedException {

        WebDriver driver = new ChromeDriver();
        driver.get("http://develop.migrational.com");

        driver.manage().window().maximize();


        Thread.sleep(3000);
        driver.findElement(By.linkText("Login")).click();
        Thread.sleep(3000);
        driver.findElement(By.id("email")).sendKeys("bla123@gmail.com");
        Thread.sleep(2000);
        driver.findElement(By.id("password")).sendKeys("blabla1234");
        Thread.sleep(2000);
        driver.findElement(By.id("remember_me")).click();
        Thread.sleep(2000);
        driver.findElement(By.cssSelector("button[type='submit']")).click();
        Thread.sleep(4000);

        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,500)");
        Thread.sleep(2000);

        List<WebElement> stepTitles = driver.findElements(By.cssSelector
                ("div[class='text-gray-color-500 font-medium text-base leading-19px mb-1']"));
        for (WebElement stepTitle : stepTitles) {
            String titleText =stepTitle.getText();
            if(titleText.equalsIgnoreCase("Personal information"))
            {
                System.out.println(titleText);
                driver.findElement(By.cssSelector("a[href='/prescreening/nostrification']")).click();
            }
        }
        js.executeScript("window.scrollBy(0,-500)");
        Thread.sleep(2000);


        List<WebElement> radioButtons = driver.findElements(By.cssSelector("input[type='radio']"));
        for(WebElement radioBtn : radioButtons){
            String buttonId = radioBtn.getAttribute("id");
            Thread.sleep(2000);
            if(buttonId.contains("n_yes") && !radioBtn.isSelected())
            {
                radioBtn.click();
            }
        }
        Thread.sleep(2000);
        /*WebElement gatheringDocumentsRadioBtn = driver.findElement(By.cssSelector("input[id='process_of_gathering']"));
        gatheringDocumentsRadioBtn.click();*/
        for(WebElement radioBtn : radioButtons){
            String buttonId = radioBtn.getAttribute("id");
            if(buttonId.equalsIgnoreCase("process_of_gathering") && !radioBtn.isSelected())
            {
                radioBtn.click();
            }
        }
        Thread.sleep(2000);

        for(WebElement radioBtn : radioButtons){
            String buttonId = radioBtn.getAttribute("id");
            if(buttonId.equalsIgnoreCase("started_and_avaiting") && !radioBtn.isSelected())
            {
                radioBtn.click();
            }
        }
        Thread.sleep(2000);

        js.executeScript("window.scrollBy(0,300)");
        Thread.sleep(2000);


        Select dayOfSubmission = new Select(driver.findElement(By.id("date_of_submission_day")));
        dayOfSubmission.selectByValue("2");
        Thread.sleep(2000);
        Select monthOfSubmission = new Select(driver.findElement(By.id("date_of_submission_month")));
        monthOfSubmission.selectByValue("March");
        Thread.sleep(2000);
        Select yearOfSubmission = new Select(driver.findElement(By.id("date_of_submission_year")));
        yearOfSubmission.selectByValue("1955");
        Thread.sleep(2000);
        Select provinceOfSubmission = new Select(driver.findElement(By.id("select_province")));
        provinceOfSubmission.selectByValue("Dortmund");
        Thread.sleep(2000);

        for(WebElement radioBtn : radioButtons){
            String buttonId = radioBtn.getAttribute("id");
            if(buttonId.equalsIgnoreCase("submitted_and_received") && !radioBtn.isSelected())
            {
                radioBtn.click();
            }
        }
        Thread.sleep(2000);

        js.executeScript("window.scrollBy(0,300)");
        Thread.sleep(2000);


        Select dayOfSubmissionReceived = new Select(driver.findElement(By.id("date_of_submission_day")));
        dayOfSubmissionReceived.selectByValue("2");
        Thread.sleep(2000);
        Select monthOfSubmissionReceived = new Select(driver.findElement(By.id("date_of_submission_month")));
        monthOfSubmissionReceived.selectByValue("March");
        Thread.sleep(2000);
        Select yearOfSubmissionReceived = new Select(driver.findElement(By.id("date_of_submission_year")));
        yearOfSubmissionReceived.selectByValue("1955");
        Thread.sleep(2000);
        Select provinceOfSubmissionReceived = new Select(driver.findElement(By.id("select_province")));
        provinceOfSubmissionReceived.selectByValue("Dortmund");
        Thread.sleep(4000);

        int j;
        int deleteSvgCount = driver.findElements(By.cssSelector("div[class='cursor-pointer']")).size();
        System.out.println(deleteSvgCount);
        for (j = 0; j < deleteSvgCount; j++){
            String uploadText = driver.findElements(By.cssSelector("span[class='text-gray-color-300']")).get(j).getText();
            if(uploadText.contains("NostrificationDocumentFile.png")){
                driver.findElements(By.cssSelector("div[class='cursor-pointer']")).get(j).click();
                Thread.sleep(4000);
                driver.findElement(By.xpath("//button[.='Confirm']")).click();
                Thread.sleep(4000);
              /*   driver.findElement(By.xpath("//button[.='Close']")).click();
                Thread.sleep(4000);*//*
       driver.findElement(By.xpath("//button[.='Ok']")).click();
        Thread.sleep(4000);*/
            }
        }

        List<WebElement> certificateuploadLinks =
                driver.findElements(By.cssSelector("input[type='file']"));
        for(WebElement certificateUploadLink : certificateuploadLinks){
            String uploadLinkId = certificateUploadLink.getAttribute("id");
            if(uploadLinkId.equalsIgnoreCase("nostrification_document_file"))
            {
                certificateUploadLink.sendKeys("C:/Users/USER/Documents/MigrationalPngs/NostrificationDocumentFile.png");
            }
        }



        driver.findElement(By.xpath("//a[.='Save & Close']")).click();
        Thread.sleep(4000);
        driver.findElement(By.xpath("//button[.='Confirm']")).click();
        Thread.sleep(4000);
        driver.findElement(By.xpath("//button[.='Ok']")).click();
        Thread.sleep(8000);
        driver.quit();


















    }
}