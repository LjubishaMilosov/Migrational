package org.migrational;

import org.migrational.pom.base.BaseTest;
import org.migrational.pom.pages.HomePage;
import org.migrational.pom.pages.LoginPage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.html5.Storage;
import org.testng.annotations.Test;

public class LoginTest extends BaseTest {

    @Test
    public void candidateLoginTest() throws InterruptedException {

        HomePage homePage = new HomePage(driver);
        driver.get("http://develop.migrational.com");
        LoginPage loginPage = homePage.clickLoginLink();



        //String text = driver.findElement(By.cssSelector("span[class='leading-19px']")).getText();
        // String text = driver.findElement(By.cssSelector("span[class='leading-19px'] svg")).getText();
        // System.out.println(text);
        Thread.sleep(3000);
       // driver.findElement(By.linkText("Login")).click();
        Thread.sleep(3000);
        driver.findElement(By.id("email")).sendKeys("bla123@gmail.com");
        driver.findElement(By.id("password")).sendKeys("blabla1234");
        driver.findElement(By.id("remember_me")).click();
        driver.findElement(By.cssSelector("button[type='submit']")).click();
        Thread.sleep(5000);
        driver.quit();
    }
}
