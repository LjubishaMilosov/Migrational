package org.migrational;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

import java.util.List;

public class EducationQualificationsAndWorkExperienceTest {


    @Test
    public void educationAndWorkExperienceTest() throws InterruptedException {

        WebDriver driver = new ChromeDriver();
        driver.get("http://develop.migrational.com");
        driver.manage().window().maximize();


        Thread.sleep(3000);
        driver.findElement(By.linkText("Login")).click();
        Thread.sleep(3000);
        driver.findElement(By.id("email")).sendKeys("bla123@gmail.com");
        Thread.sleep(2000);
        driver.findElement(By.id("password")).sendKeys("blabla1234");
        Thread.sleep(2000);
        driver.findElement(By.id("remember_me")).click();
        Thread.sleep(2000);
        driver.findElement(By.cssSelector("button[type='submit']")).click();
        Thread.sleep(2000);
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,200)");
        Thread.sleep(2000);


        List<WebElement> stepTitles = driver.findElements(By.cssSelector
                ("div[class='text-gray-color-500 font-medium text-base leading-19px mb-1']"));
        for (WebElement stepTitle : stepTitles) {
            String titleText = stepTitle.getText();
            if (titleText.equalsIgnoreCase("Education, Qualifications and Work experience")) {
                System.out.println(titleText);
                driver.findElement(By.cssSelector("a[href='/prescreening/education']")).click();
            }
        }

        Thread.sleep(3000);
        int j;
        int deleteSvgCount = driver.findElements(By.cssSelector("div[class='cursor-pointer']")).size();
        System.out.println(deleteSvgCount);
        for (j = 0; j < deleteSvgCount; j++){
            String uploadText = driver.findElements(By.cssSelector("span[class='text-gray-color-300']")).get(j).getText();
            if(uploadText.contains("HighSchoolMedicalDegree.png")){
                driver.findElements(By.cssSelector("div[class='cursor-pointer']")).get(j).click();
                Thread.sleep(4000);
                driver.findElement(By.xpath("//button[.='Confirm']")).click();
                Thread.sleep(4000);
                /*driver.findElement(By.xpath("//button[.='Ok']")).click();
        Thread.sleep(4000);*/

            }
        }

        Thread.sleep(2000);
        List<WebElement> certificateUploadCheckBoxes = driver.findElements(By.cssSelector("input[type='checkbox']"));
        for(WebElement certificateUploadCheckBox : certificateUploadCheckBoxes){
            String uploadLinkId = certificateUploadCheckBox.getAttribute("id");
            if(uploadLinkId.equalsIgnoreCase("checkSchool_high_school") && !certificateUploadCheckBox.isSelected())
            {
                certificateUploadCheckBox.click();
            }
        }

        Thread.sleep(2000);
        List<WebElement> certificateuploadLinks =
                driver.findElements(By.cssSelector("input[type='file']"));
        for(WebElement certificateUploadLink : certificateuploadLinks){
            String uploadLinkId = certificateUploadLink.getAttribute("id");
            System.out.println(uploadLinkId);
            if(uploadLinkId.equalsIgnoreCase("level_high_school_file"))
            {
                certificateUploadLink.sendKeys("C:/Users/USER/Documents/MigrationalPngs/HighSchoolMedicalDegree.png");
            }
        }

        Thread.sleep(2000);
        for (j = 0; j < deleteSvgCount; j++){
            String uploadText = driver.findElements(By.cssSelector("span[class='text-gray-color-300']")).get(j).getText();
            if(uploadText.contains("HighMedicalSchoolPrequalification.png")){
                driver.findElements(By.cssSelector("div[class='cursor-pointer']")).get(j).click();
                Thread.sleep(4000);
                driver.findElement(By.xpath("//button[.='Confirm']")).click();
                Thread.sleep(4000);

                /*driver.findElement(By.xpath("//button[.='Ok']")).click();
                Thread.sleep(4000);*/
            }
        }

        Thread.sleep(2000);
        List<WebElement> certificateUploadCheckBoxes1 = driver.findElements(By.cssSelector("input[type='checkbox']"));
        for(WebElement certificateUploadCheckBox1 : certificateUploadCheckBoxes1){
            String uploadLinkId = certificateUploadCheckBox1.getAttribute("id");
            if(uploadLinkId.equalsIgnoreCase("checkSchool_medical_school") && !certificateUploadCheckBox1.isSelected())
            {
                certificateUploadCheckBox1.click();
            }
        }

        Thread.sleep(2000);
        List<WebElement> certificateuploadLinks1 =
                driver.findElements(By.cssSelector("input[type='file']"));
        for(WebElement certificateUploadLink1 : certificateuploadLinks1){
            String uploadLinkId = certificateUploadLink1.getAttribute("id");
            System.out.println(uploadLinkId);
            if(uploadLinkId.equalsIgnoreCase("level_medical_school_file"))
            {
                certificateUploadLink1.
                        sendKeys("C:/Users/USER/Documents/MigrationalPngs/HighMedicalSchoolPrequalification.png");
            }
        }

        Thread.sleep(2000);
        for (j = 0; j < deleteSvgCount; j++){
            String uploadText = driver.findElements(By.cssSelector("span[class='text-gray-color-300']")).get(j).getText();
            if(uploadText.contains("CollegeDegree.png")){
                driver.findElements(By.cssSelector("div[class='cursor-pointer']")).get(j).click();
                Thread.sleep(4000);
                driver.findElement(By.xpath("//button[.='Confirm']")).click();
                Thread.sleep(4000);
                /*driver.findElement(By.xpath("//button[.='Ok']")).click();
        Thread.sleep(4000);*/

            }
        }

        Thread.sleep(2000);
        List<WebElement> certificateUploadCheckBoxes2 = driver.findElements(By.cssSelector("input[type='checkbox']"));
        for(WebElement certificateUploadCheckBox2 : certificateUploadCheckBoxes2){
            String uploadLinkId = certificateUploadCheckBox2.getAttribute("id");
            if(uploadLinkId.equalsIgnoreCase("checkSchool_college_degree") && !certificateUploadCheckBox2.isSelected())
            {
                certificateUploadCheckBox2.click();
            }
        }

        Thread.sleep(2000);
        List<WebElement> certificateuploadLinks2 =
                driver.findElements(By.cssSelector("input[type='file']"));
        for(WebElement certificateUploadLink2 : certificateuploadLinks2){
            String uploadLinkId = certificateUploadLink2.getAttribute("id");
            System.out.println(uploadLinkId);
            if(uploadLinkId.equalsIgnoreCase("level_college_degree_file"))
            {
                certificateUploadLink2.sendKeys("C:/Users/USER/Documents/MigrationalPngs/CollegeDegree.png");
            }
        }

        js.executeScript("window.scrollBy(0,400)");
        Thread.sleep(2000);

        Thread.sleep(2000);
        for (j = 0; j < deleteSvgCount; j++){
            String uploadText = driver.findElements(By.cssSelector("span[class='text-gray-color-300']")).get(j).getText();
            if(uploadText.contains("College+Specialization.png")){
                driver.findElements(By.cssSelector("div[class='cursor-pointer']")).get(j).click();
                Thread.sleep(4000);
                driver.findElement(By.xpath("//button[.='Confirm']")).click();
                Thread.sleep(4000);
                /*driver.findElement(By.xpath("//button[.='Ok']")).click();
        Thread.sleep(4000);*/

            }
        }

        Thread.sleep(2000);
        List<WebElement> certificateUploadCheckBoxes3 = driver.findElements(By.cssSelector("input[type='checkbox']"));
        for(WebElement certificateUploadCheckBox3 : certificateUploadCheckBoxes3){
            String uploadLinkId = certificateUploadCheckBox3.getAttribute("id");
            if(uploadLinkId.equalsIgnoreCase("checkSchool_college_specialization") && !certificateUploadCheckBox3.isSelected())
            {
                certificateUploadCheckBox3.click();
            }
        }

        Thread.sleep(2000);
        List<WebElement> certificateuploadLinks3 =
                driver.findElements(By.cssSelector("input[type='file']"));
        for(WebElement certificateUploadLink3 : certificateuploadLinks3){
            String uploadLinkId = certificateUploadLink3.getAttribute("id");
            System.out.println(uploadLinkId);
            if(uploadLinkId.equalsIgnoreCase("level_college_specialization_file"))
            {
                certificateUploadLink3.sendKeys("C:/Users/USER/Documents/MigrationalPngs/College+Specialization.png");
            }
        }



        Thread.sleep(2000);
        for (j = 0; j < deleteSvgCount; j++){
            String uploadText = driver.findElements(By.cssSelector("span[class='text-gray-color-300']")).get(j).getText();
            if(uploadText.contains("OtherSpecialization.png")){
                driver.findElements(By.cssSelector("div[class='cursor-pointer']")).get(j).click();
                Thread.sleep(4000);
                driver.findElement(By.xpath("//button[.='Confirm']")).click();
                Thread.sleep(4000);
                /*driver.findElement(By.xpath("//button[.='Ok']")).click();
        Thread.sleep(4000);*/

            }
        }

        Thread.sleep(2000);
        List<WebElement> certificateUploadCheckBoxes4 = driver.findElements(By.cssSelector("input[type='checkbox']"));
        for(WebElement certificateUploadCheckBox4 : certificateUploadCheckBoxes4){
            String uploadLinkId = certificateUploadCheckBox4.getAttribute("id");
            if(uploadLinkId.equalsIgnoreCase("checkSchool_other_specialization") && !certificateUploadCheckBox4.isSelected())
            {
                certificateUploadCheckBox4.click();
            }
        }

        WebElement otherSpecializationTextArea =  driver.findElement(By.cssSelector("textarea[name='other_spec_info']"));
        String otherSpecializationText = otherSpecializationTextArea.getAttribute("value");
        System.out.println(otherSpecializationText);
        if(otherSpecializationTextArea.isDisplayed())/*&& otherSpecializationText.isEmpty())*/{
            otherSpecializationTextArea.clear();
            Thread.sleep(2000);
            otherSpecializationTextArea.sendKeys("My other specialzation is false");
        }
        Thread.sleep(4000);

        List<WebElement> certificateuploadLinks4 =
                driver.findElements(By.cssSelector("input[type='file']"));
        for(WebElement certificateUploadLink4 : certificateuploadLinks4){
            String uploadLinkId = certificateUploadLink4.getAttribute("id");
            System.out.println(uploadLinkId);
            if(uploadLinkId.equalsIgnoreCase("level_other_specialization_file"))
            {
                certificateUploadLink4.sendKeys("C:/Users/USER/Documents/MigrationalPngs/OtherSpecialization.png");
            }
        }

        Thread.sleep(2000);
        List<WebElement> radioButtons = driver.findElements(By.cssSelector("input[type='radio']"));
        for(WebElement radioBtn : radioButtons){
            String buttonId = radioBtn.getAttribute("id");
            if(buttonId.equalsIgnoreCase("yes_working") && !radioBtn.isSelected())
            {
                radioBtn.click();
            }
        }

        js.executeScript("window.scrollBy(0,800)");
        Thread.sleep(2000);

        Thread.sleep(2000);
        List<WebElement> radioButtons1 = driver.findElements(By.cssSelector("input[type='radio']"));
        for(WebElement radioBtn1 : radioButtons1){
            String buttonId = radioBtn1.getAttribute("id");
            if(buttonId.equalsIgnoreCase("yes_working_g") && radioBtn1.isDisplayed())
            {
                radioBtn1.click();
            }
        }


        Thread.sleep(2000);
        WebElement selectDropdown = driver.findElement(By.id("current_province"));
        Select selectYourCurrentCity = new Select(selectDropdown);
        if(selectDropdown.isDisplayed())
        {
            selectYourCurrentCity.selectByValue("Hamburg");
        }

        Thread.sleep(2000);
        WebElement currentEmployerTextArea = driver.findElement(By.id("current_employer"));
        String currentEmployerText = currentEmployerTextArea.getAttribute("value");
        System.out.println(currentEmployerText);
        if(currentEmployerTextArea.isDisplayed() /*&& currentEmployerText.isEmpty()*/)
        {
            currentEmployerTextArea.clear();
            Thread.sleep(2000);
            currentEmployerTextArea.sendKeys("My current employer is THE BRIGHT BOX");
        }




        driver.findElement(By.xpath("//a[.='Save & Close']")).click();
        Thread.sleep(4000);
        driver.findElement(By.xpath("//button[.='Confirm']")).click();
        Thread.sleep(4000);
        driver.findElement(By.xpath("//button[.='Ok']")).click();
        Thread.sleep(8000);
        driver.quit();




    }
}
