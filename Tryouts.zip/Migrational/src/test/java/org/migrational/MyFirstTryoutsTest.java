package org.migrational;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

import java.util.List;

public class MyFirstTryoutsTest {
// css selector for login button = : ".ml-5 div > a"

    @Test
    public void registerCandidateTest() throws InterruptedException {
        //  System.setProperty("webdriver.chrome.driver","C:\\Users\\USER\\chromedriver.exe");
        WebDriver driver = new ChromeDriver();

        driver.get("http://develop.migrational.com/");
        driver.manage().window().maximize();

        driver.findElement(By.linkText("Create Account")).click();
        Thread.sleep(3000);
        driver.findElement(By.cssSelector("label[for='candidate'] ")).click();
        Thread.sleep(3000);
        driver.findElement(By.cssSelector("a[href='/registration-info/candidate']")).click();
        Thread.sleep(3000);
        driver.findElement(By.id("first_name")).sendKeys("bla");
        Thread.sleep(2000);
        driver.findElement(By.id("last_name")).sendKeys("bla");
        Thread.sleep(1000);
        driver.findElement(By.id("date_day")).click();

        Select days = new Select(driver.findElement(By.id("date_day")));
        /*
        List<WebElement> optionsDay = days.getOptions();
         System.out.println("The dropdown options are:");
        for(WebElement options : optionsDay)
            System.out.println(options.getText());
        System.out.println("Select the Option by value 19");
        days.selectByValue("19");
        System.out.println("Select value is: " + days.getFirstSelectedOption().getText());
         */

        Select months = new Select(driver.findElement(By.id("date_mounth_desktop")));
        // WebElement yearDropdown = driver.findElement(By.id("date_of_birth"));
        Select years = new Select(driver.findElement(By.id("date_of_birth")));

        days.selectByValue("29");
        Thread.sleep(2000);
        months.selectByValue("October");
        Thread.sleep(2000);
        years.selectByValue("1983");
        Thread.sleep(2000);

        Select countries = new Select(driver.findElement(By.id("country")));
        List<WebElement> optionsCountry = countries.getOptions();
        System.out.println("The dropdown options are:");
        for (WebElement options : optionsCountry)
            System.out.println(options.getText());
        Thread.sleep(2000);
        System.out.println("Select the Option by value Macedonia");
        countries.selectByVisibleText("Macedonia");
        Thread.sleep(2000);
        System.out.println("Select value is: " + countries.getFirstSelectedOption().getText());

        Select cities = new Select(driver.findElement(By.id("city")));
        List<WebElement> optionsCity = countries.getOptions();
        System.out.println("The dropdown options are:");
        for (WebElement options : optionsCity)
            System.out.println(options.getText());
        Thread.sleep(2000);
        System.out.println("Select the Option by value Probishtip");
        cities.selectByVisibleText("Probishtip");
        Thread.sleep(2000);
        System.out.println("Select value is: " + countries.getFirstSelectedOption().getText());

        driver.findElement(By.id("phone")).sendKeys("9876543");
        Thread.sleep(1000);

        driver.findElement(By.id("email")).sendKeys("bla123@gmail.com");
        Thread.sleep(1000);

        driver.findElement(By.id("password")).sendKeys("blabla1234");
        Thread.sleep(1000);

        driver.findElement(By.id("repeat_password")).sendKeys("blabla1234");
        Thread.sleep(1000);

        driver.findElement(By.id("terms_and_conditions")).click();
        Thread.sleep(5000);
        driver.findElement(By.cssSelector("button[type='submit']")).click();
        Thread.sleep(5000);

        driver.quit();
    }

    //    Check why this didn't work   !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
        // cause it's a simple select
        /*
        WebElement dayPicker = driver.findElement(By.id("date_day"));
        List<WebElement> days = dayPicker.findElements(By.linkText("19"));

        for (WebElement d:days)
        {

            if(d.getText().equals("19"))
            {
                d.click();
            }
            Thread.sleep(3000);
        }
        */


    @Test
    public void activateCandidateAccountTest () throws InterruptedException {
        WebDriver driver = new ChromeDriver();
        driver.get("http://mailhog.migrational.com/#");
        driver.manage().window().maximize();
        Thread.sleep(3000);

        int i;
        int count = driver.findElements(By.cssSelector("div[class='msglist-message row ng-scope']")).size();
        System.out.println(count);
        for (i = 0; i < count; i++) {
            String emailName = driver.findElements(By.cssSelector("div[class='ng-binding ng-scope']"))
                    .get(i).getText();
            String emailDescription = driver.findElements(By.cssSelector("span[class='subject unread ng-binding']"))
                    .get(i).getText();

            if (emailName.equalsIgnoreCase("bla123@gmail.com") &&
                    emailDescription.equalsIgnoreCase("Activate Your Account")) {
                driver.findElements(By.cssSelector("div[class='msglist-message row ng-scope']")).get(i).click();
                Thread.sleep(3000);
                break;
            }
        }

        Thread.sleep(3000);
        List<WebElement> iframeElements = driver.findElements(By.tagName("iframe"));
        System.out.println("The total number of iframes are " + iframeElements.size());
        //Switch by frame name
        driver.switchTo().frame("preview-html");

        //Switch by frame ID
        //  driver.switchTo().frame("preview-html");
        System.out.println(driver.findElement(By.linkText("Activate Account")).getText());
        driver.findElement(By.linkText("Activate Account")).click();
        Thread.sleep(5000);
        driver.switchTo().defaultContent();
        //switch to frame by web element
        //WebElement iframeElement = driver.findElement(By.id("IF1"));
        // driver.switchTo().frame(iframeElement);

        //String text = driver.findElement(By.cssSelector("span[class='leading-19px']")).getText();
        // String text = driver.findElement(By.cssSelector("span[class='leading-19px'] svg")).getText();
        // System.out.println(text);

        Thread.sleep(5000);
        driver.quit();


        //driver.findElement(By.id("email")).sendKeys("bibi@gmail.com");

    }


    @Test
    public void loginCandidateTest() throws InterruptedException {

        WebDriver driver = new ChromeDriver();
        driver.get("http://develop.migrational.com");
        driver.manage().window().maximize();

        //String text = driver.findElement(By.cssSelector("span[class='leading-19px']")).getText();
        // String text = driver.findElement(By.cssSelector("span[class='leading-19px'] svg")).getText();
        // System.out.println(text);
        Thread.sleep(3000);
        driver.findElement(By.linkText("Login")).click();
        Thread.sleep(3000);
        driver.findElement(By.id("email")).sendKeys("bla123@gmail.com");
        driver.findElement(By.id("password")).sendKeys("blabla1234");
        driver.findElement(By.id("remember_me")).click();
        driver.findElement(By.cssSelector("button[type='submit']")).click();
        Thread.sleep(5000);
        driver.quit();
    }

    @Test
    public void sendResetPasswordMailTest() throws InterruptedException {

        WebDriver driver = new ChromeDriver();
        driver.get("http://develop.migrational.com");
        driver.manage().window().maximize();
        Thread.sleep(3000);
        driver.findElement(By.linkText("Login")).click();
        Thread.sleep(3000);
        driver.findElement(By.linkText("Forgot password?")).click();
        Thread.sleep(3000);
        driver.findElement(By.id("email")).sendKeys("mbmb@gmail.com");
        Thread.sleep(3000);
        driver.findElement(By.cssSelector("button[type='submit']")).click();
        Thread.sleep(3000);
        String text = driver.findElement(By.xpath("//h1[contains(text(),'Check in your email')]")).getText();
        Thread.sleep(3000);
        System.out.println(text);

        /*   code to check the 'click here' link in case reset password mail wasn't sent the first time

        driver.findElement(By.linkText("click here")).click();
        driver.findElement(By.id("email")).sendKeys("mbmb@gmail.com");
        Thread.sleep(3000);
        driver.findElement(By.cssSelector("button[type='submit']")).click();
        Thread.sleep(3000);
        */

    }

    @Test
    public void passwordResetTest() throws InterruptedException {
        WebDriver driver = new ChromeDriver();
        driver.get("http://mailhog.migrational.com/#");
        driver.manage().window().maximize();
        Thread.sleep(3000);

        int i;
        int count = driver.findElements(By.cssSelector("div[class='msglist-message row ng-scope']")).size();
        System.out.println(count);
        for (i = 0; i < count; i++) {
            String emailName = driver.findElements(By.cssSelector("div[class='ng-binding ng-scope']"))
                    .get(i).getText();
            String emailDescription = driver.findElements(By.cssSelector("span[class='subject unread ng-binding']"))
                    .get(i).getText();

            if (emailName.equalsIgnoreCase("lala@gmail.com") &&
                    emailDescription.equalsIgnoreCase("Reset Password Notification")) {
                driver.findElements(By.cssSelector("div[class='msglist-message row ng-scope']")).get(i).click();
                Thread.sleep(3000);
                break;
            }
        }

        Thread.sleep(3000);
        List<WebElement> iframeElements = driver.findElements(By.tagName("iframe"));
        System.out.println("The total number of iframes are " + iframeElements.size());
        //Switch by frame name
        driver.switchTo().frame("preview-html");

        //Switch by frame ID
        //  driver.switchTo().frame("preview-html");
        System.out.println(driver.findElement(By.linkText("Reset Password")).getText());
        driver.findElement(By.linkText("Reset Password")).click();
        Thread.sleep(5000);
        driver.switchTo().defaultContent();


        // following code fail because the driver is out of scope or something:
       /*
       String resetMsg = driver.findElement(By.xpath("//h1[contains(text(),'Reset your password')]")).getText();
        System.out.println(resetMsg);
        driver.findElement(By.id("new-password")).sendKeys("mbmb12345@gmail.com");
        Thread.sleep(3000);
        driver.findElement(By.id("confirm-password")).sendKeys("mbmb12345@gmail.com");
        Thread.sleep(3000);
        driver.findElement(By.cssSelector("button[type='submit']")).click();
        */

        Thread.sleep(5000);
        driver.quit();






}
    @Test
    public void preScreeningStepsTest() throws InterruptedException {

        WebDriver driver = new ChromeDriver();
        driver.get("http://develop.migrational.com");
        driver.manage().window().maximize();

        //String text = driver.findElement(By.cssSelector("span[class='leading-19px']")).getText();
        // String text = driver.findElement(By.cssSelector("span[class='leading-19px'] svg")).getText();
        // System.out.println(text);
        Thread.sleep(3000);
        driver.findElement(By.linkText("Login")).click();
        Thread.sleep(3000);
        driver.findElement(By.id("email")).sendKeys("bla123@gmail.com");
        Thread.sleep(2000);
        driver.findElement(By.id("password")).sendKeys("blabla1234");
        Thread.sleep(2000);
        driver.findElement(By.id("remember_me")).click();
        Thread.sleep(2000);
        driver.findElement(By.cssSelector("button[type='submit']")).click();
        Thread.sleep(2000);















        List<WebElement> radioButtons = driver.findElements(By.cssSelector("div[id='personal_div'] input[type ='radio']"));
        for (WebElement radioButton : radioButtons) {
            if (radioButton.getAttribute("value").equalsIgnoreCase("married")) {
                System.out.println(radioButton.getAttribute("value"));
                radioButton.click();
            }
            break;
        }

        Select yourGender = new Select(driver.findElement(By.id("cust_gender")));
        yourGender.selectByValue("1");
        Thread.sleep(2000);

        String uploadPersonalPhoto = driver.findElement(By.cssSelector("div[id='personal_div'] input[type='file']"))
                .getAttribute("id");
        System.out.println(uploadPersonalPhoto);
        if(uploadPersonalPhoto.equalsIgnoreCase("covid_cert_file"))
        {
            driver.findElement(By.cssSelector("div[id='personal_div'] input[type='file']"))
                    .sendKeys("C:/Users/USER/Downloads/1.png");
        }



        String uploadCV = driver.findElement(By.cssSelector("div[id='personal_div'] input[type='file']"))
                .getAttribute("id");
        System.out.println(uploadCV);
        if(uploadCV.equalsIgnoreCase("user_cv_file"))
        {
            driver.findElement(By.cssSelector("div[id='personal_div'] input[type='file']"))
                    .sendKeys("C:/Users/USER/Downloads/spellingNostrification.png");
        }


//     div[id='personal_div'] p[class='text-base leading-5 ml-3 mr-3 flex-1']
      /*
        List<WebElement> uploads = driver.findElements(
                By.cssSelector("div[id='personal_div'] p[class='text-base leading-5 ml-3 mr-3 flex-1']"));
        for (WebElement uploadPhoto : uploads) {
            if (uploadPhoto.getText().equalsIgnoreCase("Attach your photo\n" +
                    "Supports PNG, JPG")) {
                System.out.println(uploadPhoto.getText());
               // uploadPhoto.sendKeys("C:\\Users\\USER\\Downloads\\Spelling nostrification.png");
            }
        }
*/


        List<WebElement> uploads1 = driver.findElements(
                By.cssSelector("div[id='personal_div'] p[class='text-base leading-5 ml-3 mr-3 flex-1']"));
        for (WebElement uplooadCV : uploads1) {
            if (uplooadCV.getText().equalsIgnoreCase("Attach your CV\n" +
                    "PDF, Word, PNG, JPG")) {
                System.out.println(uplooadCV.getText());
               // uploadCV.click();
               // uploadCV.sendKeys("Downloads\\line.png");
            }
        }
/*
        int m;
        int count4 = driver.findElements(
                By.cssSelector("div[id='personal_div'] p[class='text-base leading-5 ml-3 mr-3 flex-1']")).size();
        System.out.println(count4);
        for (m = 0; m < count; m++) {
            String uploadPhoto = driver.findElements
                            (By.cssSelector("div[id='personal_div'] p[class='text-base leading-5 ml-3 mr-3 flex-1']"))
                    .get(m).getText();
            //System.out.println(uploadPhoto);
            if
            (uploadPhoto.equalsIgnoreCase("Attach your photo\n" +
                    "Supports PNG, JPG")) {
                System.out.println(uploadPhoto);
                Thread.sleep(3000);
            }
            break;


        }*/
        Thread.sleep(2000);
        List<WebElement> germanLevelLinks = driver.findElements(By.cssSelector("[href='/prescreening/german-level']"));
        for (WebElement germanLevelLink : germanLevelLinks) {
            if (germanLevelLink.getText().equalsIgnoreCase("Next")) {
                germanLevelLink.click();
            }

        }

        List<WebElement> doYouKnowGermanBtns = driver.findElements(By.cssSelector("div[id='german_div'] input[type ='radio']"));
        for (WebElement doYouKnowGermanYes : doYouKnowGermanBtns) {
            String gerLevel  = doYouKnowGermanYes.getAttribute("value");
            System.out.println("Do you know Greman? Answer: "+gerLevel);
            if (!gerLevel.equalsIgnoreCase("yes")) {
                System.out.println(doYouKnowGermanYes.getAttribute("value"));
                doYouKnowGermanYes.click();
            }
            break;
        }
        Select germanLevel = new Select(driver.findElement(By.id("level_knowledge")));
        germanLevel.selectByValue("B2");
        Thread.sleep(2000);

        Thread.sleep(5000);
        driver.quit();
    }


    @Test
    public void germanLevelTest() throws InterruptedException {


        WebDriver driver = new ChromeDriver();
        driver.get("http://develop.migrational.com");
        driver.manage().window().maximize();

        Thread.sleep(3000);
        driver.findElement(By.linkText("Login")).click();
        Thread.sleep(3000);
        driver.findElement(By.id("email")).sendKeys("bla123@gmail.com");
        Thread.sleep(2000);
        driver.findElement(By.id("password")).sendKeys("blabla1234");
        Thread.sleep(2000);
        driver.findElement(By.id("remember_me")).click();
        Thread.sleep(2000);
        driver.findElement(By.cssSelector("button[type='submit']")).click();
        Thread.sleep(2000);
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,250)");
        Thread.sleep(2000);

        List<WebElement> stepTitles = driver.findElements(By.cssSelector
                ("div[class='text-gray-color-500 font-medium text-base leading-19px mb-1']"));
        for (WebElement stepTitle : stepTitles) {
            String titleText =stepTitle.getText();
            if(titleText.equalsIgnoreCase("German language proficiency levels"))
            {
                System.out.println(titleText);
                driver.findElement(By.cssSelector("a[href='/prescreening/german-level']")).click();
            }
        }

        List<WebElement> radioButtons = driver.findElements(By.cssSelector("input[type='radio']"));
        for(WebElement radioBtn : radioButtons){
            String buttonId = radioBtn.getAttribute("id");
            if(buttonId.equalsIgnoreCase("yes_know_german") && !radioBtn.isSelected())
            {
                radioBtn.click();
            }
        }

        Select germanKnowledgeLevel = new Select(driver.findElement(By.id("level_knowledge")));
        germanKnowledgeLevel.selectByValue("B1");
        Thread.sleep(2000);

        //     input[id='checkCerf_CEFR']
        //    input[name='certificates']
        List<WebElement> certificateUploadCheckBoxes = driver.findElements(By.cssSelector("input[name='certificates']"));
        for(WebElement certificateUploadCheckBox : certificateUploadCheckBoxes){
            String uploadLinkId = certificateUploadCheckBox.getAttribute("id");
            if(uploadLinkId.equalsIgnoreCase("checkCerf_CEFR") && !certificateUploadCheckBox.isSelected())
            {
                certificateUploadCheckBox.click();
            }
        }
        Thread.sleep(5000);
       // p[class='text-base leading-5 ml-3 mr-3 flex-1']
        List<WebElement> certificateuploadLinks =
                driver.findElements(By.cssSelector("p[class='text-base leading-5 ml-3 mr-3 flex-1']"));
        for(WebElement certificateUploadLink : certificateuploadLinks){
            String uploadLinkId = certificateUploadLink.getAttribute("id");
            if(uploadLinkId.equalsIgnoreCase("checkCerf_TELC") && !certificateUploadLink.isSelected())
            {
                driver.findElements(By.cssSelector("p[class='text-base leading-5 ml-3 mr-3 flex-1']")).size();
                certificateUploadLink.sendKeys("C:/Users/USER/Downloads/spellingNostrification.png");
            }
        }
        Thread.sleep(5000);
    }




    @Test
    public void reasonsForApplyingTest() throws InterruptedException {


        WebDriver driver = new ChromeDriver();
        driver.get("http://develop.migrational.com");
        driver.manage().window().maximize();


        Thread.sleep(3000);
        driver.findElement(By.linkText("Login")).click();
        Thread.sleep(3000);
        driver.findElement(By.id("email")).sendKeys("bla123@gmail.com");
        Thread.sleep(2000);
        driver.findElement(By.id("password")).sendKeys("blabla1234");
        Thread.sleep(2000);
        driver.findElement(By.id("remember_me")).click();
        Thread.sleep(2000);
        driver.findElement(By.cssSelector("button[type='submit']")).click();
        Thread.sleep(2000);
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,5000)");
        Thread.sleep(2000);

        List<WebElement> stepTitles = driver.findElements(By.cssSelector
                ("div[class='text-gray-color-500 font-medium text-base leading-19px mb-1']"));
        for (WebElement stepTitle : stepTitles) {
            String titleText =stepTitle.getText();
            if(titleText.equalsIgnoreCase("Reasons for applying and expectations"))
            {
                System.out.println(titleText);
                driver.findElement(By.cssSelector("a[href='/prescreening/reasons-for-applying']")).click();
            }
        }
    }


    @Test
    public void nostrificationTest() throws InterruptedException {


        WebDriver driver = new ChromeDriver();
        driver.get("http://develop.migrational.com");
        driver.manage().window().maximize();


        Thread.sleep(3000);
        driver.findElement(By.linkText("Login")).click();
        Thread.sleep(3000);
        driver.findElement(By.id("email")).sendKeys("bla123@gmail.com");
        Thread.sleep(2000);
        driver.findElement(By.id("password")).sendKeys("blabla1234");
        Thread.sleep(2000);
        driver.findElement(By.id("remember_me")).click();
        Thread.sleep(2000);
        driver.findElement(By.cssSelector("button[type='submit']")).click();
        Thread.sleep(4000);
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,800)");
        Thread.sleep(2000);
       // driver.findElement(By.cssSelector("a[href='/prescreening/nostrification']")).click();


        List<WebElement> stepTitles = driver.findElements(By.cssSelector
                ("div[class='text-gray-color-500 font-medium text-base leading-19px mb-1']"));
        for (WebElement stepTitle : stepTitles) {
            String titleText =stepTitle.getText();
            if(titleText.equalsIgnoreCase("Nostrification"))
            {
                System.out.println(titleText);
                driver.findElement(By.cssSelector("a[href='/prescreening/nostrification']")).click();
            }
        }

        /*int i;
        int count = driver.findElements(By.cssSelector
                ("div[class='text-gray-color-500 font-medium text-base leading-19px mb-1']")).size();
        System.out.println(count);
        for (i = 0; i < count; i++) {
            String stepTitle = driver.findElements(By.cssSelector
                    ("div[class='text-gray-color-500 font-medium text-base leading-19px mb-1']")).get(i).getText();
            if (stepTitle.equalsIgnoreCase("Nostrification")){
                System.out.println(stepTitle);
                driver.findElement(By.cssSelector("a[href='/prescreening/nostrification']")).click();
                Thread.sleep(3000);
                break;
            }
        }*/
        Thread.sleep(2000);

    }


}