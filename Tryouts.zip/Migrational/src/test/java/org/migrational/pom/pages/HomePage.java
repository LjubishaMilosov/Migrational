package org.migrational.pom.pages;

import org.migrational.pom.base.BasePage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class HomePage extends BasePage {

    private final By loginLink = By.linkText("Login");

    public HomePage(WebDriver driver) {
        super(driver);
    }

    public LoginPage clickLoginLink(){
        driver.findElement(loginLink).click();
        return new LoginPage(driver);
    }
}
