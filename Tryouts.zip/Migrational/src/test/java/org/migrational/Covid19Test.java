package org.migrational;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

import java.util.List;

public class Covid19Test {


    @Test
    public void covid19VaccinationTest() throws InterruptedException {


        WebDriver driver = new ChromeDriver();
        driver.get("http://develop.migrational.com");
        driver.manage().window().maximize();


        Thread.sleep(3000);
        driver.findElement(By.linkText("Login")).click();
        Thread.sleep(3000);
        driver.findElement(By.id("email")).sendKeys("bla123@gmail.com");
        Thread.sleep(2000);
        driver.findElement(By.id("password")).sendKeys("blabla1234");
        Thread.sleep(2000);
        driver.findElement(By.id("remember_me")).click();
        Thread.sleep(2000);
        driver.findElement(By.cssSelector("button[type='submit']")).click();
        Thread.sleep(4000);

        List<WebElement> stepTitles = driver.findElements(By.cssSelector
                ("div[class='text-gray-color-500 font-medium text-base leading-19px mb-1']"));
        for (WebElement stepTitle : stepTitles) {
            String titleText =stepTitle.getText();
            if(titleText.equalsIgnoreCase("COVID-19 vaccination"))
            {
                System.out.println(titleText);
                driver.findElement(By.cssSelector("a[href='/prescreening/covid-vaccine']")).click();
            }
        }
        Thread.sleep(2000);

        WebElement radioButton = driver.findElement(By.cssSelector("input[id='no']"));
        String yesButtonId = radioButton.getAttribute("id");
        if(yesButtonId.equalsIgnoreCase("no") && !radioButton.isSelected())
        {
            radioButton.click();
        }
        Thread.sleep(2000);
        List<WebElement> radioButtons = driver.findElements(By.cssSelector("input[type='radio']"));
        for(WebElement radioBtn : radioButtons){
            String buttonId = radioBtn.getAttribute("id");
            if(buttonId.equalsIgnoreCase("yes") && !radioBtn.isSelected())
            {
                radioBtn.click();
            }
        }




        Select numOfVaccines = new Select(driver.findElement(By.id("vaccine_dose")));
        numOfVaccines.selectByValue("3");

        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,800)");
        Thread.sleep(2000);

        Select firstVaccine = new Select(driver.findElement(By.cssSelector("select[id='vaccine_1']")));
        firstVaccine.selectByValue("janssen");
        Select secondVaccine = new Select(driver.findElement(By.cssSelector("select[id='vaccine_2']")));
        secondVaccine.selectByValue("spikevax_moderna");
        Select thirdVaccine = new Select(driver.findElement(By.cssSelector("select[id='vaccine_3']")));
        thirdVaccine.selectByValue("vaxzevria_astrazeneca");
        Thread.sleep(2000);

        List<WebElement> uploadLinks = driver.findElements(By.cssSelector("input[type='file']"));
        for(WebElement uploadLink : uploadLinks){
            String linkId = uploadLink.getAttribute("id");
            if(linkId.equalsIgnoreCase("covid_cert_file"))
            {
                uploadLink.sendKeys("C:/Users/USER/Documents/MigrationalPngs/COVID19Certificate.png");
            }
        }
        Thread.sleep(4000);

        int j;
        int deleteSvgCount = driver.findElements(By.cssSelector("div[class='cursor-pointer']")).size();
        System.out.println(deleteSvgCount);
        for (j = 0; j < deleteSvgCount; j++){
            String uploadText = driver.findElements(By.cssSelector("span[class='text-gray-color-300']")).get(j).getText();
            System.out.println(uploadText);
            if(uploadText.contains("COVID19Certificate.png")){
                driver.findElements(By.cssSelector("div[class='cursor-pointer']")).get(j).click();
                Thread.sleep(4000);
                driver.findElement(By.xpath("//button[.='Confirm']")).click();
                Thread.sleep(4000);
                /* driver.findElement(By.xpath("//button[.='Close']")).click();
                Thread.sleep(4000);*/
                driver.findElement(By.xpath("//button[.='Ok']")).click();
                Thread.sleep(4000);
            }
        }

        List<WebElement> uploadLinks1 = driver.findElements(By.cssSelector("input[type='file']"));
        for(WebElement uploadLink : uploadLinks1){
            String linkId = uploadLink.getAttribute("id");
            if(linkId.equalsIgnoreCase("covid_cert_file"))
            {
                uploadLink.sendKeys("C:/Users/USER/Documents/MigrationalPngs/COVID19Certificate.png");
            }
        }

        Thread.sleep(4000);

        driver.findElement(By.xpath("//a[.='Save & Close']")).click();
        Thread.sleep(4000);
        driver.findElement(By.xpath("//button[.='Confirm']")).click();
        Thread.sleep(4000);
        driver. findElement(By.xpath("//button[.='Ok']")).click();
        Thread.sleep(8000);
        driver.quit();

    }


    }


