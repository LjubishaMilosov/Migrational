package org.migrational;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

import java.util.List;

public class PersonalInformationTest {



    @Test
    public void personalInformationTest() throws InterruptedException {


        WebDriver driver = new ChromeDriver();
        driver.get("http://develop.migrational.com");
        driver.manage().window().maximize();


        Thread.sleep(3000);
        driver.findElement(By.linkText("Login")).click();
        Thread.sleep(3000);
        driver.findElement(By.id("email")).sendKeys("bla123@gmail.com");
        Thread.sleep(2000);
        driver.findElement(By.id("password")).sendKeys("blabla1234");
        Thread.sleep(2000);
        driver.findElement(By.id("remember_me")).click();
        Thread.sleep(2000);
        driver.findElement(By.cssSelector("button[type='submit']")).click();
        Thread.sleep(2000);

        List<WebElement> stepTitles = driver.findElements(By.cssSelector
                ("div[class='text-gray-color-500 font-medium text-base leading-19px mb-1']"));
        for (WebElement stepTitle : stepTitles) {
            String titleText =stepTitle.getText();
            if(titleText.equalsIgnoreCase("Personal information"))
            {
                System.out.println(titleText);
                driver.findElement(By.cssSelector("a[href='/prescreening/personal-information']")).click();
            }
        }

        // nema potreba od ovoj kod. megutoa ima BUG odnosno vrednosta za country of birth
        // ne se zema od registracija kako sto se zema za current country of rezidence, current city i date of birth !!!
        Thread.sleep(2000);
        Select countryOfBirth = new Select(driver.findElement(By.id("birth_country")));
        countryOfBirth.selectByValue("Macedonia");
        Thread.sleep(2000);
        Select dayOfBirth = new Select(driver.findElement(By.id("day_of_birth")));
        dayOfBirth.selectByValue("20");
        Thread.sleep(2000);
        Select monthOfBirth = new Select(driver.findElement(By.id("month_of_birth")));
        monthOfBirth.selectByValue("October");
        Thread.sleep(2000);
        Select yearOfBirth = new Select(driver.findElement(By.id("year_of_birth")));
        yearOfBirth.selectByValue("1983");
        Thread.sleep(2000);

        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,400)");
        Thread.sleep(2000);

        List<WebElement> radioButtons = driver.findElements(By.cssSelector("input[type='radio']"));
        for(WebElement radioBtn : radioButtons){
            String buttonId = radioBtn.getAttribute("id");
            if(buttonId.equalsIgnoreCase("married") && !radioBtn.isSelected())
            {
                radioBtn.click();
            }
        }

        Thread.sleep(2000);
        Select selectYourGender = new Select(driver.findElement(By.id("cust_gender")));
        selectYourGender.selectByValue("3");

        js.executeScript("window.scrollBy(0,500)");
        Thread.sleep(2000);








       int j;
        int deleteSvgCount = driver.findElements(By.cssSelector("div[class='cursor-pointer']")).size();
        System.out.println(deleteSvgCount);
        for (j = 0; j < deleteSvgCount; j++){
            String uploadText = driver.findElements(By.cssSelector("span[class='text-gray-color-300']")).get(j).getText();
            System.out.println(uploadText);
            if(uploadText.contains("ProfilePhoto.png")){
                driver.findElements(By.cssSelector("div[class='cursor-pointer']")).get(j).click();
                Thread.sleep(4000);
                driver.findElement(By.xpath("//button[.='Confirm']")).click();
                Thread.sleep(4000);
               /*  driver.findElement(By.xpath("//button[.='Close']")).click();
                Thread.sleep(4000);*/
       /*driver.findElement(By.xpath("//button[.='Ok']")).click();
        Thread.sleep(4000);*/
            }
        }
        Thread.sleep(4000);


        List<WebElement> uploadLinks = driver.findElements(By.cssSelector("input[type='file']"));
        for(WebElement uploadLink : uploadLinks){
            String linkId = uploadLink.getAttribute("id");
            if(linkId.equalsIgnoreCase("user_image"))
            {
                uploadLink.sendKeys("C:/Users/USER/Documents/MigrationalPngs/ProfilePhoto.png");
            }
        }
        Thread.sleep(4000);
        int i;
        int deleteSvgCount1 = driver.findElements(By.cssSelector("div[class='cursor-pointer']")).size();
        System.out.println(deleteSvgCount1);
        for (i = 0; i < deleteSvgCount1; i++){
            String uploadText = driver.findElements(By.cssSelector("span[class='text-gray-color-300']")).get(i).getText();
            System.out.println(uploadText);
            if(uploadText.contains("CVFile.png")){
                driver.findElements(By.cssSelector("div[class='cursor-pointer']")).get(i).click();
                Thread.sleep(4000);
                driver.findElement(By.xpath("//button[.='Confirm']")).click();
                Thread.sleep(4000);
               /*  driver.findElement(By.xpath("//button[.='Close']")).click();
                Thread.sleep(4000);*/
       /*driver.findElement(By.xpath("//button[.='Ok']")).click();
        Thread.sleep(4000);*/
            }
        }
        List<WebElement> uploadLinks1 = driver.findElements(By.cssSelector("input[type='file']"));
        for(WebElement uploadLink1 : uploadLinks1){
            String linkId = uploadLink1.getAttribute("id");
            if(linkId.equalsIgnoreCase("user_cv_file"))
            {
                uploadLink1.sendKeys("C:/Users/USER/Documents/MigrationalPngs/CVFile.png");
            }
        }
        Thread.sleep(4000);


//if ciklusot paga na testiranje najverojatno zatoa sto ima greska vo kodot:
// SVG oblceto nedostasuva na 'upload photo' linkot



        driver.findElement(By.xpath("//a[.='Save & Close']")).click();
        Thread.sleep(4000);
        driver.findElement(By.xpath("//button[.='Confirm']")).click();
        Thread.sleep(4000);
        driver.findElement(By.xpath("//button[.='Ok']")).click();
        Thread.sleep(4000);

    }

    }


