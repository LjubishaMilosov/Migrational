package org.migrational;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

import java.util.List;

public class ReasonsForApplyingAndExpectationsTest {

    @Test
    public void reasonsForApplyingTest() throws InterruptedException {

        WebDriver driver = new ChromeDriver();
        driver.get("http://develop.migrational.com");
        driver.manage().window().maximize();


        Thread.sleep(3000);
        driver.findElement(By.linkText("Login")).click();
        Thread.sleep(3000);
        driver.findElement(By.id("email")).sendKeys("bla123@gmail.com");
        Thread.sleep(2000);
        driver.findElement(By.id("password")).sendKeys("blabla1234");
        Thread.sleep(2000);
        driver.findElement(By.id("remember_me")).click();
        Thread.sleep(2000);
        driver.findElement(By.cssSelector("button[type='submit']")).click();
        Thread.sleep(4000);

        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,500)");
        Thread.sleep(2000);

        List<WebElement> stepTitles = driver.findElements(By.cssSelector
                ("div[class='text-gray-color-500 font-medium text-base leading-19px mb-1']"));
        for (WebElement stepTitle : stepTitles) {
            String titleText =stepTitle.getText();
            if(titleText.equalsIgnoreCase("Personal information"))
            {
                System.out.println(titleText);
                driver.findElement(By.cssSelector("a[href='/prescreening/reasons-for-applying']")).click();
            }
        }

        Thread.sleep(2000);
        Select selectYourGender = new Select(driver.findElement(By.id("reasons")));
        selectYourGender.selectByValue("system_and_organization");
        Thread.sleep(2000);

        List<WebElement> radioButtons = driver.findElements(By.cssSelector("input[type='radio']"));
        for(WebElement radioBtn : radioButtons){
            String buttonId = radioBtn.getAttribute("id");
            System.out.println(buttonId);
            if(buttonId.equalsIgnoreCase("yes_work") && !radioBtn.isSelected())
            {
                radioBtn.click();
            }
        }

        WebElement changeCurrentJobReasonsTextArea =  driver.findElement(By.cssSelector("textarea[name='reason_for_job_change']"));
        String describeYourReasonsText = changeCurrentJobReasonsTextArea.getAttribute("value");
        System.out.println(describeYourReasonsText);
        if(changeCurrentJobReasonsTextArea.isDisplayed() /*&& describeYourReasonsText.isEmpty()*/){
            changeCurrentJobReasonsTextArea.clear();
            Thread.sleep(2000);
            changeCurrentJobReasonsTextArea.sendKeys("Better working conditions");
        }
        Thread.sleep(4000);

        js.executeScript("window.scrollBy(0,500)");
        Thread.sleep(2000);

        for(WebElement radioBtn : radioButtons){
            String buttonId = radioBtn.getAttribute("id");
            if(buttonId.equalsIgnoreCase("yes_in_germany") && !radioBtn.isSelected())
            {
                radioBtn.click();
            }
        }


        Select yourCurrentLocation = new Select(driver.findElement(By.id("currently_in_city")));
        yourCurrentLocation.selectByValue("Frankfurt");
        Thread.sleep(2000);

        for(WebElement radioBtn : radioButtons){
            String buttonId = radioBtn.getAttribute("id");
            if(buttonId.equalsIgnoreCase("yes_job") && !radioBtn.isSelected())
            {
                radioBtn.click();
            }
        }
        Thread.sleep(2000);

        js.executeScript("window.scrollBy(0,500)");
        Thread.sleep(2000);

        for(WebElement radioBtn : radioButtons){
            String buttonId = radioBtn.getAttribute("id");
            if(buttonId.equalsIgnoreCase("by_air") && !radioBtn.isSelected())
            {
                radioBtn.click();
            }
        }
        Thread.sleep(2000);

        Select accommodationPreference = new Select(driver.findElement(By.name("accommodation")));
        accommodationPreference.selectByValue("platform_to_assist");
        Thread.sleep(2000);


        Select communicateWithPotentialEmployers = new Select(driver.findElement(By.id("communication")));
        communicateWithPotentialEmployers.selectByValue("the_platform");
        Thread.sleep(2000);

        Select takeFamilyWithYou = new Select(driver.findElement(By.id("fam")));
       /* takeFamilyWithYou.selectByValue("depends");
        Thread.sleep(2000);*/


        takeFamilyWithYou.selectByValue("yes");
        Thread.sleep(2000);

        WebElement familyComeInfoTextArea =  driver.findElement(By.cssSelector("textarea[name='family_come_info']"));
        String familyComeInfoText = familyComeInfoTextArea.getAttribute("value");
        System.out.println(familyComeInfoTextArea);
        if(familyComeInfoTextArea.isDisplayed() /*&& familyComeInfoText.isEmpty()*/){
            familyComeInfoTextArea.clear();
            Thread.sleep(2000);
            familyComeInfoTextArea.sendKeys("My family will come if the company provides visas");
        }/*else{
            familyComeInfoTextArea.clear();
            familyComeInfoTextArea.sendKeys("My family will arrive with me");
        }*/
        Thread.sleep(4000);

        for(WebElement radioBtn : radioButtons){
            String buttonId = radioBtn.getAttribute("id");
            if(buttonId.equalsIgnoreCase("yes_children") && !radioBtn.isSelected())
            {
                radioBtn.click();
            }
        }
        Thread.sleep(2000);

        js.executeScript("window.scrollBy(0,500)");
        Thread.sleep(2000);

        WebElement childrenAge = driver.findElement(By.name("children_age"));
        Select selectChildrenAge = new Select(childrenAge);
        if(childrenAge.isDisplayed())
        {
            selectChildrenAge.selectByValue("above_and_under_16");
        }
        Thread.sleep(2000);

        Select howLongToStay = new Select(driver.findElement(By.id("stay")));
        howLongToStay.selectByValue("three_to_10_years");
        Thread.sleep(2000);

        Select preferredCity = new Select(driver.findElement(By.id("preferred_city")));
        preferredCity.selectByValue("Frankfurt");
        Thread.sleep(2000);

        js.executeScript("window.scrollBy(0,500)");
        Thread.sleep(2000);

        Select yearsOfWorkExperience = new Select(driver.findElement(By.id("years_of_work_experience")));
        yearsOfWorkExperience.selectByValue("three_plus_years");
        Thread.sleep(2000);

        Select howDidYoyHearAboutUs = new Select(driver.findElement(By.id("how_heard_about_us")));
        howDidYoyHearAboutUs.selectByValue("other");
        Thread.sleep(2000);

        WebElement heardAboutUsTextArea =  driver.findElement(By.cssSelector("textarea[name='how_heard_about_us_info']"));
        String heardAboutUsText = heardAboutUsTextArea.getAttribute("value");
        System.out.println(familyComeInfoTextArea);
        if(heardAboutUsTextArea.isDisplayed() && heardAboutUsText.isEmpty()){
            heardAboutUsTextArea.sendKeys("A friend recommended you");
        }
        Thread.sleep(4000);

        driver.findElement(By.xpath("//a[.='Save & Close']")).click();
        Thread.sleep(4000);
        driver.findElement(By.xpath("//button[.='Confirm']")).click();
        Thread.sleep(4000);
        driver.findElement(By.xpath("//button[.='Ok']")).click();
        Thread.sleep(8000);
        driver.quit();


















    }
}