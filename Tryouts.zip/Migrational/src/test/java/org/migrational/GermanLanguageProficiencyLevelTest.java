package org.migrational;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

import java.util.List;

public class GermanLanguageProficiencyLevelTest {


    @Test
    public void germanLevelTest() throws InterruptedException {


        WebDriver driver = new ChromeDriver();
        driver.get("http://develop.migrational.com");
        driver.manage().window().maximize();

        Thread.sleep(3000);
        driver.findElement(By.linkText("Login")).click();
        Thread.sleep(3000);
        driver.findElement(By.id("email")).sendKeys("bla123@gmail.com");
        Thread.sleep(2000);
        driver.findElement(By.id("password")).sendKeys("blabla1234");
        Thread.sleep(2000);
        driver.findElement(By.id("remember_me")).click();
        Thread.sleep(2000);
        driver.findElement(By.cssSelector("button[type='submit']")).click();
        Thread.sleep(2000);
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,250)");
        Thread.sleep(2000);

        List<WebElement> stepTitles = driver.findElements(By.cssSelector
                ("div[class='text-gray-color-500 font-medium text-base leading-19px mb-1']"));
        for (WebElement stepTitle : stepTitles) {
            String titleText =stepTitle.getText();
            if(titleText.equalsIgnoreCase("German language proficiency levels"))
            {
                System.out.println(titleText);
                driver.findElement(By.cssSelector("a[href='/prescreening/german-level']")).click();
            }
        }

        List<WebElement> radioButtons = driver.findElements(By.cssSelector("input[type='radio']"));
        for(WebElement radioBtn : radioButtons){
            String buttonId = radioBtn.getAttribute("id");
            if(buttonId.equalsIgnoreCase("yes_know_german") && !radioBtn.isSelected())
            {
                radioBtn.click();
            }
        }

        Select germanKnowledgeLevel = new Select(driver.findElement(By.id("level_knowledge")));
        germanKnowledgeLevel.selectByValue("B1");
        Thread.sleep(2000);


        int j;
        int deleteSvgCount = driver.findElements(By.cssSelector("div[class='cursor-pointer']")).size();
        System.out.println(deleteSvgCount);
        for (j = 0; j < deleteSvgCount; j++){
            String uploadText = driver.findElements(By.cssSelector("span[class='text-gray-color-300']")).get(j).getText();
            if(uploadText.contains("CEFRcertificate.png")){
                driver.findElements(By.cssSelector("div[class='cursor-pointer']")).get(j).click();
                Thread.sleep(4000);
                driver.findElement(By.xpath("//button[.='Confirm']")).click();
                Thread.sleep(4000);
              /*   driver.findElement(By.xpath("//button[.='Close']")).click();
                Thread.sleep(4000);*//*
       driver.findElement(By.xpath("//button[.='Ok']")).click();
        Thread.sleep(4000);*/
            }
        }




        List<WebElement> certificateUploadCheckBoxes = driver.findElements(By.cssSelector("input[type='checkbox']"));
        for(WebElement certificateUploadCheckBox : certificateUploadCheckBoxes){
            String uploadLinkId = certificateUploadCheckBox.getAttribute("id");
            if(uploadLinkId.equalsIgnoreCase("checkCerf_CEFR") && !certificateUploadCheckBox.isSelected())
            {
                certificateUploadCheckBox.click();
            }
        }
        Thread.sleep(5000);
        List<WebElement> certificateuploadLinks =
                driver.findElements(By.cssSelector("input[type='file']"));
        for(WebElement certificateUploadLink : certificateuploadLinks){
            String uploadLinkId = certificateUploadLink.getAttribute("id");
            if(uploadLinkId.equalsIgnoreCase("cert_CEFR_file"))
            {
                certificateUploadLink.sendKeys("C:/Users/USER/Documents/MigrationalPngs/CEFRcertificate.png");
            }
        }

        js.executeScript("window.scrollBy(0,200)");
        Thread.sleep(2000);
        for (j = 0; j < deleteSvgCount; j++){
            String uploadText = driver.findElements(By.cssSelector("span[class='text-gray-color-300']")).get(j).getText();
            if(uploadText.contains("TELCcertificate.png")){
                driver.findElements(By.cssSelector("div[class='cursor-pointer']")).get(j).click();
                Thread.sleep(4000);
                driver.findElement(By.xpath("//button[.='Confirm']")).click();
                Thread.sleep(4000);
              /*   driver.findElement(By.xpath("//button[.='Close']")).click();
                Thread.sleep(4000);*//*
       driver.findElement(By.xpath("//button[.='Ok']")).click();
        Thread.sleep(4000);*/
            }
        }
        List<WebElement> certificateUploadCheckBoxes2 = driver.findElements(By.cssSelector("input[type='checkbox']"));
        for(WebElement certificateUploadCheckBox2 : certificateUploadCheckBoxes2){
            String uploadLinkId = certificateUploadCheckBox2.getAttribute("id");
            if(uploadLinkId.equalsIgnoreCase("checkCerf_TELC") && !certificateUploadCheckBox2.isSelected())
            {
                certificateUploadCheckBox2.click();
            }
        }
        Thread.sleep(5000);
        List<WebElement> radioButtons3 = driver.findElements(By.cssSelector("input[type='radio']"));
        for(WebElement radioBtn3 : radioButtons3){
            String buttonId = radioBtn3.getAttribute("id");
            if(buttonId.equalsIgnoreCase("yes_B2") && !radioBtn3.isSelected())
            {
                radioBtn3.click();
            }
        }
        List<WebElement> certificateuploadLinks3 =
                driver.findElements(By.cssSelector("input[type='file']"));
        for(WebElement certificateUploadLink3 : certificateuploadLinks3){
            String uploadLinkId = certificateUploadLink3.getAttribute("id");
            System.out.println(uploadLinkId);
            if(uploadLinkId.equalsIgnoreCase("cert_TELC_file"))
            {
                certificateUploadLink3.sendKeys("C:/Users/USER/Documents/MigrationalPngs/TELCcertificate.png");
            }
        }

        js.executeScript("window.scrollBy(0,100)");
        Thread.sleep(2000);

        for (j = 0; j < deleteSvgCount; j++){
            String uploadText = driver.findElements(By.cssSelector("span[class='text-gray-color-300']")).get(j).getText();
            if(uploadText.contains("ÖSDcertificate.png")){
                driver.findElements(By.cssSelector("div[class='cursor-pointer']")).get(j).click();
                Thread.sleep(4000);
                driver.findElement(By.xpath("//button[.='Confirm']")).click();
                Thread.sleep(4000);
              /*   driver.findElement(By.xpath("//button[.='Close']")).click();
                Thread.sleep(4000);*//*
       driver.findElement(By.xpath("//button[.='Ok']")).click();
        Thread.sleep(4000);*/
            }
        }
         List<WebElement> certificateUploadCheckBoxes4 = driver.findElements(By.cssSelector("input[type='checkbox']"));
        for(WebElement certificateUploadCheckBox4 : certificateUploadCheckBoxes4){
            String uploadLinkId = certificateUploadCheckBox4.getAttribute("id");
            if(uploadLinkId.equalsIgnoreCase("checkCerf_ÖSD") && !certificateUploadCheckBox4.isSelected())
            {
                certificateUploadCheckBox4.click();
            }
        }
        Thread.sleep(5000);
          List<WebElement> certificateuploadLinks4 =
                             driver.findElements(By.cssSelector("input[type='file']"));
        for(WebElement certificateUploadLink4 : certificateuploadLinks4){
            String uploadLinkId = certificateUploadLink4.getAttribute("id");
            System.out.println(uploadLinkId);
            if(uploadLinkId.equalsIgnoreCase("cert_ÖSD_file"))
            {
                certificateUploadLink4.sendKeys("C:/Users/USER/Documents/MigrationalPngs/ÖSDcertificate.png");
            }
        }
        js.executeScript("window.scrollBy(0,100)");
        Thread.sleep(2000);
        for (j = 0; j < deleteSvgCount; j++){
            String uploadText = driver.findElements(By.cssSelector("span[class='text-gray-color-300']")).get(j).getText();
            if(uploadText.contains("ECLcertificate.png")){
                driver.findElements(By.cssSelector("div[class='cursor-pointer']")).get(j).click();
                Thread.sleep(4000);
                driver.findElement(By.xpath("//button[.='Confirm']")).click();
                Thread.sleep(4000);
              /*   driver.findElement(By.xpath("//button[.='Close']")).click();
                Thread.sleep(4000);*//*
       driver.findElement(By.xpath("//button[.='Ok']")).click();
        Thread.sleep(4000);*/
            }
        }
         List<WebElement> certificateUploadCheckBoxes5 = driver.findElements(By.cssSelector("input[type='checkbox']"));
        for(WebElement certificateUploadCheckBox5 : certificateUploadCheckBoxes5){
            String uploadLinkId = certificateUploadCheckBox5.getAttribute("id");
            if(uploadLinkId.equalsIgnoreCase("checkCerf_ECL") && !certificateUploadCheckBox5.isSelected())
            {
                certificateUploadCheckBox5.click();
            }
        }
        Thread.sleep(5000);
          List<WebElement> certificateuploadLinks5 =
                      driver.findElements(By.cssSelector("input[type='file']"));
        for(WebElement certificateUploadLink5 : certificateuploadLinks5){
            String uploadLinkId = certificateUploadLink5.getAttribute("id");
            System.out.println(uploadLinkId);
            if(uploadLinkId.equalsIgnoreCase("cert_ECL_file"))
            {
                certificateUploadLink5.sendKeys("C:/Users/USER/Documents/MigrationalPngs/ECLcertificate.png");
            }
        }

        js.executeScript("window.scrollBy(0,100)");
        Thread.sleep(2000);

       /*  List<WebElement> certificateUploadCheckBoxes6 = driver.findElements(By.cssSelector("input[type='checkbox']"));
        for(WebElement certificateUploadCheckBox6 : certificateUploadCheckBoxes6){
            String uploadLinkId = certificateUploadCheckBox6.getAttribute("id");
            if(uploadLinkId.equalsIgnoreCase("checkCertificate") && !certificateUploadCheckBox6.isSelected())
            {
                certificateUploadCheckBox6.click();
            }
        }*/

        Thread.sleep(5000);
        driver.findElement(By.xpath("//a[.='Save & Close']")).click();
        Thread.sleep(4000);
        driver.findElement(By.xpath("//button[.='Confirm']")).click();
        Thread.sleep(4000);
        driver.findElement(By.xpath("//button[.='Ok']")).click();
        Thread.sleep(4000);
        driver.quit();
    }


}


