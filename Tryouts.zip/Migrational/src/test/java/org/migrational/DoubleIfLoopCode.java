package org.migrational;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import java.util.List;

public class DoubleIfLoopCode {


    @Test
    public void dummyTest5() throws InterruptedException {
        WebDriver driver = new ChromeDriver();
        driver.get("http://mailhog.migrational.com/#");
        driver.manage().window().maximize();
        Thread.sleep(3000);


        int i;
        int count = driver.findElements(By.cssSelector("div[class='msglist-message row ng-scope']")).size();
        System.out.println(count);
        for (i = 0; i < count; i++) {
            String emailName = driver.findElements(By.cssSelector("div[class='ng-binding ng-scope']"))
                    .get(i).getText();
            String emailDescription = driver.findElements(By.cssSelector("span[class='subject unread ng-binding']"))
                    .get(i).getText();
                if (emailName.equalsIgnoreCase("lala@gmail.com") &&
                        emailDescription.equalsIgnoreCase("Reset Password Notification")) {
                    driver.findElements(By.cssSelector("div[class='msglist-message row ng-scope']")).get(i).click();
                    Thread.sleep(3000);
                    break;
                }
        }
        int j;
        int deleteSvgCount = driver.findElements(By.cssSelector("div[class='cursor-pointer']")).size();
        System.out.println(deleteSvgCount);
        for (j = 0; j < count; j++){
            String uploadText = driver.findElements(By.cssSelector("span[class='text-gray-color-300']")).get(j).getText();
            if(uploadText.contains("spellingNostrification.png")){
                driver.findElements(By.cssSelector("div[class='cursor-pointer']")).get(j).click();
                Thread.sleep(4000);
                driver.findElement(By.xpath("//button[.='Confirm']")).click();
                Thread.sleep(4000);
                driver.findElement(By.xpath("//button[.='Close']")).click();
                Thread.sleep(4000);
       /* driver.findElement(By.xpath("//button[.='Ok']")).click();
        Thread.sleep(4000);*/
            }
        }

        List<WebElement> deleteUploadSvgs = driver.findElements(By.cssSelector("div[class='cursor-pointer']"));
        for(WebElement deleteUploadSvg : deleteUploadSvgs) {
            String uploadText = driver.findElement(By.cssSelector("span[class='text-gray-color-300']")).getText();

            if(uploadText.contains("spellingNostrification.png") && deleteUploadSvg.isDisplayed()){
                deleteUploadSvg.click();
                Thread.sleep(4000);
                driver.findElement(By.xpath("//button[.='Confirm']")).click();
                Thread.sleep(4000);
                driver.findElement(By.xpath("//button[.='Close']")).click();
                Thread.sleep(4000);
       /* driver.findElement(By.xpath("//button[.='Ok']")).click();
        Thread.sleep(4000);*/
            }
        }


            Thread.sleep(3000);
            List<WebElement> iframeElements = driver.findElements(By.tagName("iframe"));
            System.out.println("The total number of iframes are " + iframeElements.size());
            //Switch by frame name
            driver.switchTo().frame("preview-html");

            //Switch by frame ID
            //  driver.switchTo().frame("preview-html");
            System.out.println(driver.findElement(By.linkText("Reset Password")).getText());
            driver.findElement(By.linkText("Reset Password")).click();
            Thread.sleep(5000);
            driver.switchTo().defaultContent();

            // following code fail because the driver is out of scope of somehing:
            /*driver.findElement(By.id("new-password")).sendKeys("mbmb12345@gmail.com");
            Thread.sleep(3000);
            driver.findElement(By.id("confirm-password")).sendKeys("mbmb12345@gmail.com");
            Thread.sleep(3000);
            driver.findElement(By.cssSelector("button[type='submit']")).click();*/


            Thread.sleep(5000);
            driver.quit();


        }






    /*int i;
    int count = driver.findElements(By.cssSelector("div[class='cursor-pointer']")).size();
        for (i = 0; i < count; i++) {
        String uploadText = driver.findElements(By.cssSelector("span[class='text-gray-color-300']")).get(i).getText();
        if(uploadText.equalsIgnoreCase("705112926line.png"))
        {
            driver.findElements(By.cssSelector("div[class='cursor-pointer']")).get(i).click();
            Thread.sleep(4000);
            driver.findElement(By.xpath("//button[.='Confirm']")).click();
            Thread.sleep(4000);
            driver.findElement(By.xpath("//button[.='Close']")).click();
            Thread.sleep(4000);
       *//* driver.findElement(By.xpath("//button[.='Ok']")).click();
        Thread.sleep(4000);*//*
        }*/
    }


